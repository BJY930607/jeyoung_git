package com.example.inavitestapp;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class CheckPermissionActivity extends AppCompatActivity {
    private final int MY_REQUEST_PERMISSION = 3849;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)){
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            finish();

        }else{
            requestPermission(this,MY_REQUEST_PERMISSION);
        }

    }
    private boolean checkSelfPermission(Activity activity, String permission){
        int result = ActivityCompat.checkSelfPermission(activity, permission);
        if(result == PackageManager.PERMISSION_GRANTED)return true;
        else return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == MY_REQUEST_PERMISSION && grantResults[0] != PackageManager.PERMISSION_DENIED){
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            finish();
        }else{
            showRequestAgaintDialog();
        }
    }

    private void requestPermission(Activity activity, int requestCode){
        if(Build.VERSION.SDK_INT >= 23){
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, MY_REQUEST_PERMISSION);
        }
    }
    private void showRequestAgaintDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("권한 요청을 거부 할 경우 앱 이용이 불가능 합니다.");
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try{
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:"+getPackageName()));
                    startActivity(intent);
                    finishAffinity();
                }catch (ActivityNotFoundException e){
                    e.printStackTrace();
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
                    startActivity(intent);
                    finishAffinity();
                }

            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finishAffinity();
            }
        });
        builder.create();
        builder.show();
    }

}
