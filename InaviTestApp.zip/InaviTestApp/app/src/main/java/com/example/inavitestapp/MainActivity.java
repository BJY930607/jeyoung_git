package com.example.inavitestapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Size;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.ui.PlayerControlView;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.onItemClickInterface {
    private Context mContext;
    private PlayerView mPlayerView;
    private SimpleExoPlayer mPlayer = null;
    private boolean mBooleanPlayReady = true;
    private ProgressiveMediaSource mMediaSource;
    private ImageButton mScreenChangeBtn;
    private RecyclerView mRecyclerView;
    private long mTime = 0;
    private Button mSmallButton;
    private boolean mScreenFlagsLand = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exo_player);
        mContext = this;
        mPlayerView = findViewById(R.id.exo_play1);
        mSmallButton = findViewById(R.id.small_screen);
        mScreenChangeBtn = mPlayerView.findViewById(R.id.full_screen);
        DisplayMetrics outMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(outMetrics);
        int xPx = Math.round(80 * outMetrics.xdpi);
        int yPx = Math.round(80 * outMetrics.ydpi);
        mScreenChangeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("BJY", " : onClick");
                mScreenFlagsLand = true;
                mRecyclerView.setVisibility(View.GONE);
                mScreenChangeBtn.setVisibility(View.GONE);
                mSmallButton.setVisibility(View.VISIBLE);
                setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                LinearLayout.LayoutParams params =
                        (LinearLayout.LayoutParams)mRecyclerView.getLayoutParams();
                params.weight = 0;
                mRecyclerView.setLayoutParams(params);
            }
        });
        mSmallButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("BJY", " : onClick");
                mScreenFlagsLand = false;
                mRecyclerView.setVisibility(View.VISIBLE);
                mScreenChangeBtn.setVisibility(View.VISIBLE);
                mSmallButton.setVisibility(View.GONE);
                mRecyclerView.setVisibility(View.VISIBLE);
                setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

                LinearLayout.LayoutParams params =
                        (LinearLayout.LayoutParams)mRecyclerView.getLayoutParams();

                params.weight = 6;
            }
        });
        mRecyclerView = findViewById(R.id.recycler12);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(getItems(xPx, yPx), this);
        mRecyclerView.setAdapter(adapter);
    }

    private ArrayList<VideoListViewItem> getItems(int xPx, int yPx) {
        ArrayList<VideoListViewItem> itemList = new ArrayList<VideoListViewItem>();
        long id;
        String name;
        int duration;
        Uri videoUri;
        Bitmap bitmap = null;
        String[] projection = {MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE};

        String sortOrder = MediaStore.Video.Media.DISPLAY_NAME + " ASC";
        Cursor cursor = mContext.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder);
        int idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
        int nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
        int durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);
        if (cursor != null) {
            Log.d("count111:", "" + cursor.getCount());
            while (cursor.moveToNext()) {
                id = cursor.getLong(idColumn);
                name = cursor.getString(nameColumn);
                duration = cursor.getInt(durationColumn);
                videoUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                try {
                    bitmap = mContext.getContentResolver().loadThumbnail(videoUri, new Size(xPx, yPx), null);
                } catch (IOException e) {
                    Log.d("IOE", "" + e);
                }
                Log.d("data", "id : " + id + " / name : " + name + " / duration : " + duration);
                itemList.add(new VideoListViewItem(bitmap, name, videoUri));
            }
        }

        cursor.close();

        return itemList;

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mPlayer != null && mPlayer.isPlaying()) {
            mTime = mPlayer.getContentPosition();
            mPlayer.stop();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.release();
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPlayer != null) {
            mPlayer.prepare(mMediaSource);
            mPlayer.seekTo(mTime);
        }

    }


    private void playVideo(Uri uri) {

        DataSource.Factory factory = new DefaultDataSourceFactory(mContext,
                Util.getUserAgent(mContext, this.getApplicationInfo().name));

        mMediaSource = new ProgressiveMediaSource.Factory(factory).createMediaSource(uri);
        mPlayer = new SimpleExoPlayer.Builder(mContext).build();
        mPlayer.setPlayWhenReady(true);
        mPlayerView.setPlayer(mPlayer);

        mPlayerView.setControllerVisibilityListener(new PlayerControlView.VisibilityListener() {
            @Override
            public void onVisibilityChange(int visibility) {

            }
        });

        mPlayer.prepare(mMediaSource);
        mPlayer.setPlayWhenReady(mBooleanPlayReady);

    }

    @Override
    public void onItemSelect(View v, int position, VideoListViewItem item) {
        Log.d("touch", " : " + position + " item : " + item.getmUri());
        if (mPlayer != null && mPlayer.isPlaying()) {
            if (mPlayer.isPlaying()) {
                mPlayer.release();
            }
        }
        playVideo(item.getmUri());

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d("BJY", "screenChange");
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            mScreenFlagsLand = false;
            mRecyclerView.setVisibility(View.VISIBLE);
            LinearLayout.LayoutParams params =
                    (LinearLayout.LayoutParams)mRecyclerView.getLayoutParams();

            params.weight = 6;
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            mScreenFlagsLand = true;
            mRecyclerView.setVisibility(View.GONE);
            LinearLayout.LayoutParams params =
                    (LinearLayout.LayoutParams)mRecyclerView.getLayoutParams();
            params.weight = 0;
            mRecyclerView.setLayoutParams(params);

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(mScreenFlagsLand == true){
            setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }
}
