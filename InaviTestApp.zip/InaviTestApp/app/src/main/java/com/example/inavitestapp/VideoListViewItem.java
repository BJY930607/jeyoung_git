package com.example.inavitestapp;

import android.graphics.Bitmap;
import android.net.Uri;

public class VideoListViewItem {
    private Bitmap mIconBitmap;
    private String mVideoName;
    private Uri mUri;
    VideoListViewItem(Bitmap bitmap, String videoName, Uri uri){
        mIconBitmap = bitmap;
        mVideoName = videoName;
        mUri = uri;
    }
    public Uri getmUri() {
        return mUri;
    }

    public void setmUri(Uri mUri) {
        this.mUri = mUri;
    }
    public void setmIconBitmap(Bitmap mIconBitmap) {
        this.mIconBitmap = mIconBitmap;
    }

    public void setmVideoName(String mVideoName) {
        this.mVideoName = mVideoName;
    }

    public Bitmap getmBitmap() {
        return mIconBitmap;
    }

    public String getmVideoName() {
        return mVideoName;
    }




}
