package com.example.inavitestapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private ArrayList<VideoListViewItem> mData = null;

    public interface onItemClickInterface{
        void onItemSelect(View v, int position, VideoListViewItem itemqq);
    }
    private onItemClickInterface mListener;
    RecyclerViewAdapter(ArrayList<VideoListViewItem> list, onItemClickInterface listener){
        mData = list;
        mListener = listener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtView;
        ImageView imgView;
        ViewHolder(View itemView){
            super(itemView);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    int pos = getAdapterPosition();
                    if(pos != RecyclerView.NO_POSITION){
                        mListener.onItemSelect(v, pos, mData.get(pos));
                    }
                }
            });
            txtView = itemView.findViewById(R.id.listVideoName);
            imgView = itemView.findViewById(R.id.listImage);
        }
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.video_list_item, parent, false);
        RecyclerViewAdapter.ViewHolder viewHolder = new RecyclerViewAdapter.ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        VideoListViewItem item = mData.get(position);

        holder.imgView.setImageBitmap(item.getmBitmap());
        holder.txtView.setText(item.getmVideoName());

    }

    @Override
    public int getItemCount() {

        return mData.size();
    }
}
